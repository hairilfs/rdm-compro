<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Talk RDM</title>
</head>
<body>
	<p>Name: {{ $data['name'] }}</p>
	<p>Company: {{ $data['company'] }}</p>
	<p>Email: {{ $data['email'] }}</p>
	<p>Phone: {{ $data['phone'] }}</p>
	<p>Help: {{ $data['help'] }}</p>
	<p>Description: {{ $data['description'] }}</p>
</body>
</html>