<div class="preview-row" data-columns="false">
    <div class="row">
        <figure class="no-margin">
            <a class="d-block" data-fancybox="project" href="{{ $image->getImgUrl($data->project_cid) }}">
                <img class="w-fit" src="{{ $image->getImgUrl($data->project_cid) }}">
            </a>
        </figure>
    </div>
</div>