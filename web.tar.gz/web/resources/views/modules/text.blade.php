<div class="preview-intro">
	{!! $content !!}
</div>