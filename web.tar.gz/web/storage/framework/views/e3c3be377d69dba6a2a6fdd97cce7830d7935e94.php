<!DOCTYPE html>




<html lang="<?php echo e(app()->getLocale()); ?>" class="no-js">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>RDM - <?php echo $__env->yieldContent('title', ''); ?></title>
    
    <meta name="description" content="RDM">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta property="og:url" content="">
    <meta property="og:type" content="article">
    <meta property="og:title" content="">
    <meta property="og:description" content="">
    <meta property="og:image" content="">

    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="">
    <meta name="twitter:creator" content="">
    <meta name="twitter:title" content="">
    <meta name="twitter:description" content="">
    <meta name="twitter:image" content="">

    <link rel="canonical" href="" />

    <!-- <link rel="icon" type="image/png" href="assets/icon/icon.png"> -->

    <base href="<?php echo e(url('/').'/'); ?>">

    <link rel="icon" type="image/png" href="assets/icon/icon-16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="assets/icon/icon-32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="assets/icon/icon-96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="assets/icon/icon-192.png" sizes="192x192">
    <link rel="icon" type="image/png" href="assets/icon/icon-194.png" sizes="194x194">
    
    <link rel="apple-touch-icon" href="assets/icon/icon-57.png" sizes="57x57">
    <link rel="apple-touch-icon" href="assets/icon/icon-60.png" sizes="60x60">
    <link rel="apple-touch-icon" href="assets/icon/icon-72.png" sizes="72x72">
    <link rel="apple-touch-icon" href="assets/icon/icon-76.png" sizes="76x76">
    <link rel="apple-touch-icon" href="assets/icon/icon-114.png" sizes="114x114">
    <link rel="apple-touch-icon" href="assets/icon/icon-120.png" sizes="120x120">
    <link rel="apple-touch-icon" href="assets/icon/icon-144.png" sizes="144x144">
    <link rel="apple-touch-icon" href="assets/icon/icon-152.png" sizes="152x152">
    <link rel="apple-touch-icon" href="assets/icon/icon-180.png" sizes="180x180">

    <!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> -->
    
    <?php if( App::environment(['local', 'staging']) ): ?>
        <script src="../../_html/app/assets/script.js?<?php echo e(filemtime('../../_html/app/assets/script.js')); ?>"></script>
        <link rel="stylesheet" href="../../_html/app/assets/style.css?<?php echo e(filemtime('../../_html/app/assets/style.css')); ?>">
    <?php else: ?>
        <script src="<?php echo e(asset('assets/script.js?'.date('YmdH'))); ?>"></script>
        <link rel="stylesheet" href="<?php echo e(asset('assets/style.css?'.date('YmdH'))); ?>">
    <?php endif; ?>

    <?php if(isset($landing)): ?>
        <link rel="stylesheet" href="<?php echo e(asset('assets/landing.css?'.date('YmdH'))); ?>">
        <script src="<?php echo e(asset('assets/landing.js?'.date('YmdH'))); ?>"></script>

        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

          ga('create', 'UA-59002254-1', 'auto');
          ga('send', 'pageview');

        </script>
    <?php endif; ?>

    <?php echo $__env->yieldContent('head'); ?>

    <script type="text/javascript">
        window.App = <?php echo json_encode([
                'baseUrl' => url('/').'/',
                'csrfToken' => csrf_token()
            ]); ?>;
    </script>

</head>


<body class="<?php echo $__env->yieldContent('body_class', ''); ?>">

<?php echo $__env->make('partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldContent('content', ''); ?>

<?php echo $__env->make('partials.bottom-section', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
