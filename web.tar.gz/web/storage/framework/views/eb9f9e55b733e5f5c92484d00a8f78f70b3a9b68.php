<?php $__env->startSection('title', 'Project'); ?>

<?php $__env->startSection('body_class', 'project-detail'); ?>

<?php $__env->startSection('content'); ?>

<main>
    <section id="project-name">
        <div class="section--inner has-ver-padding">
            <div class="container">
                <p><?php echo e($project->partner); ?> — 
                    <?php $__currentLoopData = explode(',', $project->project_category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="#" class=" link link-white link-opaque category"><?php echo e(title_case($element)); ?></a> <?php echo e(!$loop->last ? '/' : ''); ?>    
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <h1><?php echo e($project->title); ?></h1>
            </div>
        </div>
    </section>

    <section id="project-intro">
        <div class="section--inner">
            <figure class="no-margin fullheight-js">
                <picture class="image-ad">
                    <source media="(max-width: 576px)" srcset="uploads/_temp/img-dummy-1-mobile.jpg">
                    <source media="(min-width: 577px)" srcset="<?php echo e($project->getImgUrl()); ?>">
                    <img src="<?php echo e($project->getImgUrl()); ?>" alt="">
                </picture>
            </figure>

            <div class="intro-text has-ver-padding">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-2 project-intro-info">
                            <ul>
                                <li>
                                    <p class="no-margin f-bold">Project Status</p>
                                    <p class="no-margin"><?php echo e($project->project_status); ?></p>
                                </li>

                                <li>
                                    <p class="no-margin f-bold">Partners</p>
                                    <p class="no-margin"><?php echo e($project->partner); ?></p>
                                </li>

                                <li>
                                    <p class="no-margin f-bold">Year</p>
                                    <p class="no-margin"><?php echo e($project->year); ?></p>
                                </li>
                            </ul>
                        </div>

                        <div class="col-lg-6 push-lg-4 project-intro-content">
                            <h5 class="lh-med"><?php echo e($project->excerpt); ?></h5>
                            <?php echo $project->description; ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php if($project->youtube_url): ?>

    <section id="project-video" class="has-ver-padding">
        <div class="section--inner has-ver-padding">
            <div class="container">
                <div class="video">
                    <div id="yt-player" class="vid-container embed-responsive embed-responsive-16by9">
                        <div id="player"></div>
                    </div>

                    <div id="thumb-container" class="thumb-container">
                        <?php
                            $youtube_id = $project->getYoutubeId();
                        ?>
                        <img src="http://img.youtube.com/vi/<?php echo e($youtube_id); ?>/maxresdefault.jpg">
                        <a id="start-video" class="start-video" data-fancybox="video" href="https://youtu.be/<?php echo e($youtube_id); ?>">
                            <i class="icon-play"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php endif; ?>

    <?php
        $modules = $project->modules;
    ?>
    <?php if($modules->count()): ?>
    <section id="project-preview" class="has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $element->toHtml(); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                

                <div class="preview-bottom">
                    <p class="small no-margin">Want to know more? Contact Us.</p>
                    <p class="small no-margin"><a href="mailto:us@onerdm.com" class="link f-med">us@onerdm.com</a> or <a href="tel:+628171824912839" class="link f-med">+628171824912839</a></p>
                </div>

                <div class="back-to-top text-center">
                    <a href="#" id="back-top" class="link link-opaque">
                        <i class="icon-right-open-big"></i>
                    </a>
                </div>
            </div>
        </div>
    </section>
    <?php endif; ?>
    
    <?php if($other->count()): ?>
    <section id="next-project" class="">
        <div class="section--inner">
            <a href="<?php echo e($other->getUrl()); ?>" class="d-block link link-white">
                <figure class="no-margin">
                    <img src="<?php echo e($other->getImgUrl()); ?>">
                </figure>
                <span class="overlay dark"></span>
                <div class="next-project-title">
                    <div class="container">
                        <h6 class="ls-med">NEXT PROJECT</h6>
                        <p><?php echo e($other->partner); ?> — 
                        <?php $__currentLoopData = explode(',', $project->project_category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="opaque category"><?php echo e(title_case($element)); ?></span> <?php echo e(!$loop->last ? '/' : ''); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <p class="h1 no-margin"><?php echo e($other->title); ?></p>
                    </div>
                </div>
            </a>
        </div>
    </section>
    <?php endif; ?>
</main>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
    $(document).ready(function(){
        
    });

    $(window).load(function(){
        
    });

    $(window).resize(function(){
        
    });
</script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>