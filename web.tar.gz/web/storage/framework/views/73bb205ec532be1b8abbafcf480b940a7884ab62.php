<div class="preview-row" data-columns="true">
    <div class="row">
    	<?php if(!$data->content_position): ?>
    		<div class="preview-text">
	            <?php echo $data->content; ?>

	        </div>
    	<?php endif; ?>

        <figure class="no-margin">
            <a class="d-block" data-fancybox="project" href="<?php echo e($image->getImgUrl($data->project_cid)); ?>">
                <img class="w-fit" src="<?php echo e($image->getImgUrl($data->project_cid)); ?>">
            </a>
        </figure>

    	<?php if($data->content_position): ?>
    		<div class="preview-text">
	            <?php echo $data->content; ?>

	        </div>
    	<?php endif; ?>
        
    </div>
</div>