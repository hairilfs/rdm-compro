<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Talk RDM</title>
</head>
<body>
	<p>Name: <?php echo e($data['name']); ?></p>
	<p>Company: <?php echo e($data['company']); ?></p>
	<p>Email: <?php echo e($data['email']); ?></p>
	<p>Phone: <?php echo e($data['phone']); ?></p>
	<p>Help: <?php echo e($data['help']); ?></p>
	<p>Description: <?php echo e($data['description']); ?></p>
</body>
</html>