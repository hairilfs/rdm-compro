<?php $__env->startSection('title', 'Company Who'); ?>

<?php $__env->startSection('body_class', 'company who inversed'); ?>

<?php $__env->startSection('content'); ?>

<main>
    <?php echo $__env->make('partials.company-nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section id="company-intro" class="has-ver-padding">
        <div class="section--inner">
            <div class="intro-text">
                <div class="container">
                    <p class="small ls-med f-med">INTRODUCTION</p>
                    <?php echo getAbout('who-intro', 'introduction'); ?>

                </div>
            </div>

            <?php if(getAbout('who-intro', 'youtube_url')): ?>
            <div class="intro-image has-video">
                <div class="container">
                    <div class="video">
                        <div id="yt-player" class="vid-container embed-responsive embed-responsive-16by9">
                            <div id="player"></div>
                        </div>

                        <div id="thumb-container" class="thumb-container">
                            <img src="http://img.youtube.com/vi/<?php echo e(getYoutubeId(getAbout('who-intro', 'youtube_url'))); ?>/maxresdefault.jpg">
                            <a id="start-video" class="start-video" data-fancybox="video" href="https://youtu.be/<?php echo e(getYoutubeId(getAbout('who-intro', 'youtube_url'))); ?>">
                                <i class="icon-play"></i>
                            </a>
                        </div>
                    </div>         
                </div>
            </div>
            <?php endif; ?>
        </div>
    </section>

    <section id="company-scopes" class="has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <h3 class="f-reg">
                    What we can do for you
                    <span class="opaque d-block">What we actually do</span>
                </h3>

                <div class="row">

                    <?php $__currentLoopData = $scope; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 scopes-item">
                        <figure>
                            <a href="#" class="d-block">
                                <img class="w-fit" src="<?php echo e($element->getImgUrl()); ?>">
                            </a>
                        </figure>
                        <figcaption>
                            <h5><?php echo e($element->title); ?></h5>
                            <p><?php echo e($element->description); ?></p>
                            <a href="<?php echo e($element->link_url); ?>" class="link ls-med f-med"><i class="icon-right-open-big"></i><?php echo e($element->link_text); ?></a>
                        </figcaption>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                </div>
            </div>
        </div>
    </section>

    <section id="testimony-slider" class="has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <h3 class="f-reg">Our CEO says</h3>

                <div class="slider-holder">
                    <div id="sliderTesti" class="owl-carousel slider">

                        <?php $__currentLoopData = $testimony; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <div class="profile-thumb">
                                <figure class="no-margin">
                                    <img class="w-fit" src="<?php echo e($element->getImgUrl()); ?>" alt="">
                                    <span class="overlay med"></span>
                                </figure>
                                <figcaption>
                                    <h5 class="f-reg lh-med content-line_slide">“<?php echo e($element->testimony); ?>”</h5>
                                </figcaption>
                            </div>
                            <div class="profile-info">
                                <p class="profile-name f-bold no-margin"><?php echo e($element->name); ?></p>
                                <p class="profile-position no-margin"><?php echo e($element->position); ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="company-partners" class="has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <h3 class="f-reg">Partners</h3>

                <div class="clients-body has-ver-padding">
                    <div class="row flexed">

                        <?php $__currentLoopData = $partner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="item">
                            <figure class="no-margin text-center">
                                <img src="<?php echo e($element->getImgUrl()); ?>">
                            </figure>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>

                    <p class="btn-holder text-center">
                        <a href="#" class="btn pad-lg curved ls-med f-med">VIEW ALL PARTNERS</a>
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="company-people" class="has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <h3 class="f-reg">People &amp; Culture</h3>

                <div class="team-holder">
                    <div class="row">

                        <?php $__currentLoopData = $people; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 profile-item">
                            <figure>
                                <img src="<?php echo e($element->getImgUrl()); ?>" alt="">
                            </figure>
                            <figcaption>
                                <p class="profile-name f-bold no-margin"><?php echo e($element->name); ?></p>
                                <p class="profile-position no-margin"><?php echo e($element->position); ?></p>
                            </figcaption>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>

                <a href="#" class="job-cta link link-opaque ls-med f-med"><i class="icon-right-open-big"></i>WE ARE HIRING</a>
            </div>
        </div>
    </section>

    <section id="company-mood" class="left-diagonal">
        <div class="section--inner">
            <div class="mood-holder">
                <figure class="no-margin">
                    <?php
                        $single_img = getAbout('who-image', 'who_single_img');
                    ?>
                    <picture class="image-ad">
                        <source media="(max-width: 576px)" srcset="<?php echo e('thumb_'.$single_img); ?>">
                        <source media="(min-width: 577px)" srcset="<?php echo e($single_img); ?>">
                        <img class="w-fit" src="<?php echo e($single_img); ?>" alt="">
                    </picture>
                </figure>
            </div>
        </div>
    </section>

    <section id="company-location" class="has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <h3 class="f-reg">
                    We’re everywhere
                    <span class="opaque d-block">Step into our office</span>
                </h3>

                <div class="row">
                    <div class="col-md-6 loc-indonesia">
                        <figure>
                            <a href="javascript:void(0)" class="d-block">
                                <img class="w-fit" src="<?php echo e(getAbout('who-address', 'who_address_indo_image')); ?>">
                            </a>
                        </figure>
                        <figcaption>
                            <?php echo getAbout('who-address', 'who_address_indo'); ?>

                        </figcaption>
                    </div>
                    <div class="col-md-6 loc-australia">
                        <figure>
                            <a href="javascript:void(0)" class="d-block">
                                <img class="w-fit" src="<?php echo e(getAbout('who-address', 'who_address_aus_image')); ?>">
                            </a>
                        </figure>
                        <figcaption>
                            <?php echo getAbout('who-address', 'who_address_aus'); ?>

                        </figcaption>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section id="company-talk" class="has-ver-padding">
        <div class="section--inner text-center has-ver-padding">
            <div class="container has-ver-padding">
                <div class="talk-holder has-ver-padding">
                    <h3 class="f-reg">Ready to have a chat?</h3>
                    <a href="#" class="link btn-trigger-talk link-white link-opaque small f-med ls-med"><i class="icon-right-open-big"></i>REACH OUT TO US</a>
                </div>
            </div>
        </div>
    </section>

    <section id="company-nav">
        <div class="section--inner">
            <div class="row row-no-margin">
                <div class="col-md-6">
                    <a href="<?php echo e(url('about')); ?>" class="d-block">
                        <figure class="no-margin">
                            <img src="<?php echo e($single_img); ?>">
                            <span class="overlay black"></span>
                        </figure>

                        <div class="nav-text">
                            <p class="nav-index">01</p>
                            <p class="nav-title">Who</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(url('about/what')); ?>" class="d-block">
                        <figure class="no-margin">
                            <img src="<?php echo e(getAbout('what-hero', 'what_hero_img')); ?>">
                            <span class="overlay black"></span>
                        </figure>

                        <div class="nav-text">
                            <p class="nav-index">02</p>
                            <p class="nav-title">What</p>
                        </div>
                    </a>
                </div>

                <div class="col-md-6">
                    <a href="<?php echo e(url('about/how')); ?>" class="d-block">
                        <figure class="no-margin">
                            <img src="<?php echo e(getAbout('how-hero', 'how_hero_img')); ?>">
                            <span class="overlay black"></span>
                        </figure>

                        <div class="nav-text">
                            <p class="nav-index">03</p>
                            <p class="nav-title">How</p>
                        </div>
                    </a>
                </div>
                <div class="col-md-6">
                    <a href="<?php echo e(url('about/why')); ?>" class="d-block">
                        <figure class="no-margin">
                            <img src="<?php echo e(getAbout('why-hero', 'why_hero_img')); ?>">
                            <span class="overlay black"></span>
                        </figure>

                        <div class="nav-text">
                            <p class="nav-index">04</p>
                            <p class="nav-title">Why</p>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>
</main>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
    $(document).ready(function(){
        rdm.company();
    });

    $(window).load(function(){
        
    });

    $(window).resize(function(){
        rdm.company();
    });
</script>
    
<?php $__env->stopPush(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>