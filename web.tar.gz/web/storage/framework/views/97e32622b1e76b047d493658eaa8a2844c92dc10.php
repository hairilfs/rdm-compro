<div class="preview-row" data-columns="false">
    <div class="row">
        <figure class="no-margin">
            <a class="d-block" data-fancybox="project" href="<?php echo e($image->getImgUrl($data->project_cid)); ?>">
                <img class="w-fit" src="<?php echo e($image->getImgUrl($data->project_cid)); ?>">
            </a>
        </figure>
    </div>
</div>