<footer id="footer">
	<div class="container">
		<div class="footer--inner flexed justify">
			<p class="copyright no-margin f-med">ALL CONTENT © 2018 RDM.</p>
			<?php if($em = getSetting('Contact', 'email')): ?>
			<a href="mailto:<?php echo e(strtolower($em)); ?>?Subject=Hello" target="_blank" class="link f-med"><?php echo e(strtoupper($em)); ?></a>
			<?php endif; ?>
		</div>
	</div>
</footer><!-- #footer -->