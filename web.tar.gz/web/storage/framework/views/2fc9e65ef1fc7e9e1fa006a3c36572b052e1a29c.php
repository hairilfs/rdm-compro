<div class="preview-row" data-columns="true">
    <div class="row">
        <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <figure class="no-margin">
                <a class="d-block" data-fancybox="project" href="<?php echo e($element->getImgUrl($data->project_cid)); ?>">
                    <img class="w-fit" src="<?php echo e($element->getImgUrl($data->project_cid)); ?>">
                </a>
            </figure>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>