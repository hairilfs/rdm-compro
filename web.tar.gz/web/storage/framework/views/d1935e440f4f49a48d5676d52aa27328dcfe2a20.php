<div class="preview-intro">
	<?php echo $content; ?>

</div>