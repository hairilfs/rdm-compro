<section id="bottom-section" class="has-ver-padding">
    <a href="#" id="back-top" class="link link-white">
        <i class="icon-right-open-big"></i>
    </a>
    
    <div class="container">
        <div class="section--inner flexed-desktop justify">
            <figure class="no-margin">
                <img class="img-fluid" src="assets/img/rdm-logo.png">
            </figure>

            <nav class="bottom-nav">
                <ul class="nav-list text-center no-margin">
                    <li><a href="<?php echo e(url('projects')); ?>" class="link link-white link-opaque h4">Projects</a></li>
                    <li><a href="<?php echo e(url('about')); ?>" class="link link-white link-opaque h4">About</a></li>
                    <li><a href="<?php echo e(url('contact')); ?>" class="link link-white link-opaque h4">Contact</a></li>
                </ul>
            </nav>

            <div class="social">
                <?php if($ig = getSetting('Social Media', 'ig')): ?>
                <a href="<?php echo e($ig); ?>" target="_blank" class="link link-white"><i class="icon-instagram"></i></a>
                <?php endif; ?>
                <?php if($fb = getSetting('Social Media', 'fb')): ?>
                <a href="<?php echo e($fb); ?>" target="_blank" class="link link-white"><i class="icon-facebook"></i></a>
                <?php endif; ?>
                <?php if($tw = getSetting('Social Media', 'tw')): ?>
                <a href="<?php echo e($tw); ?>" target="_blank" class="link link-white"><i class="icon-twitter"></i></a>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>