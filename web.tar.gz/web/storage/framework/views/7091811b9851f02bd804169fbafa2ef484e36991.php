<?php $__env->startSection('title', 'Projects'); ?>

<?php $__env->startSection('body_class', 'projects has-filtering inversed'); ?>

<?php $__env->startSection('content'); ?>

<main>
    <section id="project-hero" class="">
        <div class="section--inner">
            <figure class="no-margin fullheight-js">
                <picture class="image-ad fheight">
                    <source media="(max-width: 576px)" srcset="<?php echo e($slider->getImgUrl('mobile')); ?>">
                    <source media="(min-width: 577px)" srcset="<?php echo e($slider->getImgUrl()); ?>">
                    <img src="<?php echo e($slider->getImgUrl()); ?>" alt="">
                </picture>
                <span class="overlay black"></span>
            </figure>

            <div class="hero-heading text-center">
                <h1 class="f-reg">Projects</h1>
            </div>
        </div>
    </section>

    <section id="project-body" class="right-diagonal has-ver-padding">
        <div class="section--inner">
            <div class="container">
                <div class="project-filter">
                    <div class="filter-header">
                        <a href="javascript:void(0)" class="link link-white">Filter Projects</a>
                    </div>
                    <ul class="filter-list no-margin">
                        <li class="active"><a href="#" class="link filter-js" data-filter="*">All<i class="icon-right-open-big"></i></a></li>
                        <?php
                            $filters = [];
                            foreach ($projects as $value) {
                                $filters[] = explode(',', $value->project_category);
                            }

                            $filters = array_unique(array_collapse($filters));
                        ?>
                        <?php $__currentLoopData = $filters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><a href="#" class="link filter-js" data-filter=".<?php echo e($filter); ?>"><?php echo e(title_case($filter)); ?><i class="icon-right-open-big"></i></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>

                <div class="project-body has-ver-padding">
                    <div class="project-body--inner">
                        <div class="row grid">
                            <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 item<?php echo e($loop->index % 7 == 0 ? ' portrait' : ' landscape'); ?> <?php echo e(str_replace(',', ' ', $element->project_category)); ?>">
                                    <div class="project-image">
                                        <a href="<?php echo e($element->getUrl()); ?>" class="d-block link">
                                            <figure class="no-margin">
                                                <img src="<?php echo e($element->getImgThumbUrl($loop->index)); ?>">
                                            </figure>
                                            <figcaption>
                                                <p><?php echo e($element->title); ?></p>
                                                <p><?php echo e(title_case(str_replace(',', ' ', $element->project_category))); ?></p>
                                            </figcaption>
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <div class="more text-center">
                            <a href="#" class="link ls-med f-med">+ MORE PROJECTS</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
    
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>

<script>
    $(document).ready(function(){
        
    });

    $(window).load(function(){
        
    });

    $(window).resize(function(){
        
    });
</script>
    
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>